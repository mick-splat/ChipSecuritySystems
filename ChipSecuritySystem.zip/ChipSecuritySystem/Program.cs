﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace ChipSecuritySystem
{
    class Program
    {

        static void Main(string[] args)
        {

            ////////////////////////////////////////////////////////////////
            // Sample input
            var chips = new List<ColorChip>
                {
                    new ColorChip(Color.Blue, Color.Yellow),
                    new ColorChip(Color.Red, Color.Green),
                    new ColorChip(Color.Yellow, Color.Purple),
                    new ColorChip(Color.Green, Color.Purple),
                    new ColorChip(Color.Purple, Color.Green)
                };


            Console.WriteLine("Color Chip Keys in Bag Used\n");
            Thread.Sleep(1000);

            foreach (var item in chips)
            {
                Console.WriteLine(item.ToString());
            }
            ///////////////////////////////////////////////////////////////////


            string SecurityKey = null;
            ValidateBagOfChips(chips, ref SecurityKey);
            Console.ReadLine();



        }

        private static void ValidateBagOfChips(List<ColorChip> chips, ref string key)
        {

            //Test chip with a beginning blue and an end chip of green in the collectiony
            ColorChip firstCheck = chips.Find(x => (x.StartColor == Color.Blue));
            ColorChip lastCheck = chips.Find(x => (x.EndColor == Color.Green));
            //////

            if (firstCheck != null && lastCheck != null)
            {

                BuildSecurityKey(chips, Color.Blue, ref key);
            }
            else
            {
                Console.WriteLine(Constants.ErrorMessage);
            }

        }
        private static void BuildSecurityKey(List<ColorChip> chips, Color color, ref string key)
        {

            ColorChip chip = chips.Find(x => (x.StartColor == color));

            if (chip != null)
            {
                //Chip correct use it and then remove from bag
                key += $"[{chip}]";
                chips.Remove(chip);

                if (chip.EndColor == Color.Green)
                {
                    Console.WriteLine("--UNLOCKED--\n" + key);
                    Console.ReadLine();
                    return;
                }
                BuildSecurityKey(chips, chip.EndColor, ref key);

            }
            else
            {
                Console.WriteLine("\n" + key);
                Console.WriteLine(Constants.ErrorMessage);
            }
        }

    }
}
