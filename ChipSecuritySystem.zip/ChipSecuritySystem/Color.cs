﻿namespace ChipSecuritySystem
{
    public enum Color
    {
        Red,
        Green,
        Blue,
        Yellow,
        Purple,
        Orange
    }
}
